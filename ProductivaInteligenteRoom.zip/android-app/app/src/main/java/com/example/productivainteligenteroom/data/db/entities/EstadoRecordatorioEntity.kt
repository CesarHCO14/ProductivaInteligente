package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "estados_recordatorio")
data class EstadoRecordatorioEntity(
    @PrimaryKey(autoGenerate = true) val id_estado: Int = 0,
    val nombre_estado: String
)
