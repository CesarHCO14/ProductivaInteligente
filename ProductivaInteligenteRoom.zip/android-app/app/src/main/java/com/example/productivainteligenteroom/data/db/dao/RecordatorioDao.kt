package com.example.productivainteligenteroom.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RewriteQueriesToDropUnusedColumns
import androidx.room.Update
import com.example.productivainteligenteroom.data.db.entities.RecordatorioEntity
import com.example.productivainteligenteroom.data.db.models.ReminderUi

@Dao
@RewriteQueriesToDropUnusedColumns
interface RecordatorioDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: RecordatorioEntity): Long

    @Update
    suspend fun update(item: RecordatorioEntity)

    @Query("DELETE FROM recordatorios WHERE id_recordatorio = :id")
    suspend fun deleteById(id: Int)

    @Query("SELECT * FROM recordatorios WHERE id_recordatorio = :id LIMIT 1")
    suspend fun getById(id: Int): RecordatorioEntity?

    @Query("""
        SELECT r.id_recordatorio as id,
               r.titulo as titulo,
               r.nota as nota,
               t.nombre_tipo as tipo,
               COALESCE(r.lugar, '') as lugar,
               COALESCE(r.radio, 150) as radius,
               p.nombre_prioridad as prioridad,
               e.nombre_estado as estado,
               rc.nombre_recurrencia as recurrencia,
               r.latitud as latitud,
               r.longitud as longitud,
               r.fecha_recordatorio as fechaRecordatorio,
               r.hora_recordatorio as horaRecordatorio
        FROM recordatorios r
        INNER JOIN tipos_recordatorio t ON t.id_tipo = r.id_tipo
        INNER JOIN prioridades p ON p.id_prioridad = r.id_prioridad
        INNER JOIN estados_recordatorio e ON e.id_estado = r.id_estado
        INNER JOIN recurrencias rc ON rc.id_recurrencia = r.id_recurrencia
        WHERE r.id_usuario = :userId
        ORDER BY r.id_recordatorio DESC
    """)
    suspend fun getUiByUser(userId: Int): List<ReminderUi>

    @Query("""
        SELECT COUNT(*) FROM recordatorios r
        INNER JOIN estados_recordatorio e ON e.id_estado = r.id_estado
        WHERE r.id_usuario = :userId AND e.nombre_estado = 'PENDIENTE'
    """)
    suspend fun activeCountByUser(userId: Int): Int

    @Query("""
        SELECT COUNT(*) FROM recordatorios r
        INNER JOIN estados_recordatorio e ON e.id_estado = r.id_estado
        INNER JOIN tipos_recordatorio t ON t.id_tipo = r.id_tipo
        WHERE r.id_usuario = :userId AND e.nombre_estado = 'PENDIENTE' AND t.nombre_tipo = 'GEO'
    """)
    suspend fun activeGeoCountByUser(userId: Int): Int

    @Query("""
        SELECT COUNT(*) FROM recordatorios r
        INNER JOIN estados_recordatorio e ON e.id_estado = r.id_estado
        WHERE r.id_usuario = :userId
          AND e.nombre_estado = 'PENDIENTE'
          AND r.fecha_recordatorio IS NOT NULL
          AND (r.fecha_recordatorio || ' ' || COALESCE(r.hora_recordatorio, '00:00')) < :fechaHoraActual
    """)
    suspend fun overdueCount(userId: Int, fechaHoraActual: String): Int

    @Query("""
        SELECT COUNT(*) FROM recordatorios r
        INNER JOIN estados_recordatorio e ON e.id_estado = r.id_estado
        WHERE r.id_usuario = :userId
          AND e.nombre_estado = 'PENDIENTE'
          AND r.fecha_recordatorio IS NOT NULL
          AND (r.fecha_recordatorio || ' ' || COALESCE(r.hora_recordatorio, '00:00')) BETWEEN :desde AND :hasta
    """)
    suspend fun upcomingCount(userId: Int, desde: String, hasta: String): Int
}
