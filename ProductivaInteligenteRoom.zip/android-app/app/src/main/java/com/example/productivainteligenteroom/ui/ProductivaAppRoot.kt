package com.example.productivainteligenteroom.ui

import android.content.Context
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessAlarm
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.example.productivainteligenteroom.ui.screens.*
import com.example.productivainteligenteroom.vm.MainViewModel

sealed class Route(val path: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Dashboard : Route("dashboard", "Inicio", Icons.Default.Home)
    data object Gastos : Route("gastos", "Gastos", Icons.Default.AttachMoney)
    data object Habitos : Route("habitos", "Hábitos", Icons.Default.CheckCircle)
    data object Recordatorios : Route("recordatorios", "Avisos", Icons.Default.AccessAlarm)
    data object Informes : Route("informes", "Informes", Icons.Default.Assessment)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductivaAppRoot(context: Context) {
    val vm: MainViewModel = viewModel(factory = MainViewModelFactory(context))
    LaunchedEffect(Unit) { vm.init() }

    val nav = rememberNavController()
    val items = listOf(Route.Dashboard, Route.Gastos, Route.Habitos, Route.Recordatorios, Route.Informes)
    val logged by vm.isLoggedIn

    if (!logged) {
        LoginScreen(context, vm)
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Productiva Inteligente") },
                actions = {
                    IconButton(onClick = { vm.logout(context) }) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Cerrar sesión")
                    }
                }
            )
        },
        bottomBar = {
            val currentRoute = nav.currentBackStackEntryAsState().value?.destination?.route
            NavigationBar {
                items.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute == item.path,
                        onClick = { nav.navigate(item.path) { launchSingleTop = true } },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(navController = nav, startDestination = Route.Dashboard.path, modifier = Modifier.padding(pad)) {
            composable(Route.Dashboard.path) { DashboardScreen(vm) }
            composable(Route.Gastos.path) { GastosScreen(vm) }
            composable(Route.Habitos.path) { HabitosScreen(vm) }
            composable(Route.Recordatorios.path) { RecordatoriosScreen(vm) }
            composable(Route.Informes.path) { InformesScreen(context, vm) }
        }
    }
}
