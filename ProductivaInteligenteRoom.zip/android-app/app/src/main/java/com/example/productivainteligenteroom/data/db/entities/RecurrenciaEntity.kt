package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recurrencias")
data class RecurrenciaEntity(
    @PrimaryKey(autoGenerate = true) val id_recurrencia: Int = 0,
    val nombre_recurrencia: String
)
