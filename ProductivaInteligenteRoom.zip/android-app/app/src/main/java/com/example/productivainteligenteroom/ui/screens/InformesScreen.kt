package com.example.productivainteligenteroom.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.ui.charts.ExpenseTrendLineChart
import com.example.productivainteligenteroom.ui.charts.ExpensesBarChart
import com.example.productivainteligenteroom.ui.charts.HabitsPieChart
import com.example.productivainteligenteroom.ui.components.PremiumHeader
import com.example.productivainteligenteroom.ui.components.SectionCard
import com.example.productivainteligenteroom.vm.MainViewModel

@Composable
fun InformesScreen(context: Context, vm: MainViewModel) {
    val d = vm.dashboard.value
    LaunchedEffect(Unit) { vm.refreshAll() }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { PremiumHeader("Informes y análisis", "Visualización ejecutiva de gastos, hábitos y recordatorios") }

        item {
            SectionCard("Resumen ejecutivo") {
                Text("Total gastado: S/ %.2f".format(d.totalGastos), style = MaterialTheme.typography.bodyMedium)
                Text("Promedio diario: S/ %.2f".format(d.promedioDiario), style = MaterialTheme.typography.bodyMedium)
                Text("Proyección mensual: S/ %.2f".format(d.proyeccionMensual), style = MaterialTheme.typography.bodyMedium)
                Text("Productividad: ${vm.productivityPercent()}%", style = MaterialTheme.typography.bodyMedium)
                Text("Recordatorios activos: ${d.recordatoriosActivos}", style = MaterialTheme.typography.bodyMedium)
            }
        }

        item { Text("Gráfico 1: gastos por categoría", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item {
            SectionCard("Distribución de gastos") {
                val chartData = vm.categoryTotals()
                if (chartData.isEmpty()) Text("No hay datos para mostrar")
                else ExpensesBarChart(chartData, Modifier.fillMaxWidth().height(260.dp))
            }
        }

        item { Text("Gráfico 2: tendencia reciente", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item {
            SectionCard("Tendencia de gastos") {
                val items = vm.expenses.value
                if (items.isEmpty()) Text("No hay datos para mostrar")
                else ExpenseTrendLineChart(items, Modifier.fillMaxWidth().height(260.dp))
            }
        }

        item { Text("Gráfico 3: estado de hábitos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item {
            SectionCard("Cumplimiento de hábitos") {
                val items = vm.habits.value
                if (items.isEmpty()) Text("No hay hábitos para mostrar")
                else HabitsPieChart(items, Modifier.fillMaxWidth().height(280.dp))
            }
        }

        item {
            SectionCard("Indicadores adicionales") {
                Text("Cantidad de gastos: ${vm.expenses.value.size}")
                Text("Cantidad de hábitos: ${vm.habits.value.size}")
                Text("Cantidad de recordatorios: ${vm.reminders.value.size}")
                Text("Categoría top: ${vm.categoryTotals().firstOrNull()?.categoria ?: "Sin datos"}")
            }
        }

        item {
            SectionCard("Acción") {
                Button(onClick = {
                    val chooser = android.content.Intent.createChooser(vm.shareReportIntent(context), "Compartir reporte")
                    context.startActivity(chooser)
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("Compartir reporte")
                }
            }
        }
    }
}
