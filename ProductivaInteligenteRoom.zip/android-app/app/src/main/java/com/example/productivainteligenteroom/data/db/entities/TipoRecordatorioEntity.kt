package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tipos_recordatorio")
data class TipoRecordatorioEntity(
    @PrimaryKey(autoGenerate = true) val id_tipo: Int = 0,
    val nombre_tipo: String
)
