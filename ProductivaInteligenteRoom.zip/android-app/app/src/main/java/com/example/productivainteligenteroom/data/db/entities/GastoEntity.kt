package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "gastos",
    foreignKeys = [
        ForeignKey(
            entity = UsuarioEntity::class,
            parentColumns = ["id_usuario"],
            childColumns = ["id_usuario"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = CategoriaGastoEntity::class,
            parentColumns = ["id_categoria"],
            childColumns = ["id_categoria"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("id_usuario"), Index("id_categoria")]
)
data class GastoEntity(
    @PrimaryKey(autoGenerate = true) val id_gasto: Int = 0,
    val id_usuario: Int,
    val id_categoria: Int,
    val titulo: String,
    val monto: Double,
    val fecha: String
)
