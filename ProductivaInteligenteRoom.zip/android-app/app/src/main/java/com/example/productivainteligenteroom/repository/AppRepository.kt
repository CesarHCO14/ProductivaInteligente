package com.example.productivainteligenteroom.repository

import android.content.Context
import com.example.productivainteligenteroom.data.db.AppDatabase
import com.example.productivainteligenteroom.data.db.entities.*
import com.example.productivainteligenteroom.data.db.models.CategoryAmount
import com.example.productivainteligenteroom.data.db.models.DashboardUi
import com.example.productivainteligenteroom.data.db.models.ExpenseUi
import com.example.productivainteligenteroom.data.db.models.HabitUi
import com.example.productivainteligenteroom.data.db.models.ReminderUi
import com.example.productivainteligenteroom.data.db.models.UserUi
import java.time.LocalDate

class AppRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val usuarioDao = db.usuarioDao()
    private val categoriaDao = db.categoriaGastoDao()
    private val gastoDao = db.gastoDao()
    private val habitoDao = db.habitoDao()
    private val catalogoDao = db.catalogoRecordatorioDao()
    private val recordatorioDao = db.recordatorioDao()

    suspend fun seedDatabase() {
        if (usuarioDao.count() > 0) return

        usuarioDao.insert(UsuarioEntity(nombre = "Usuario Demo", correo = "demo@demo.com", clave = "123456"))

        categoriaDao.insertAll(
            listOf(
                CategoriaGastoEntity(nombre_categoria = "Comida"),
                CategoriaGastoEntity(nombre_categoria = "Transporte"),
                CategoriaGastoEntity(nombre_categoria = "Servicios"),
                CategoriaGastoEntity(nombre_categoria = "Ocio"),
                CategoriaGastoEntity(nombre_categoria = "Hogar")
            )
        )

        catalogoDao.insertTipos(listOf(
            TipoRecordatorioEntity(nombre_tipo = "HORA"),
            TipoRecordatorioEntity(nombre_tipo = "GEO")
        ))
        catalogoDao.insertPrioridades(listOf(
            PrioridadEntity(nombre_prioridad = "ALTA"),
            PrioridadEntity(nombre_prioridad = "MEDIA"),
            PrioridadEntity(nombre_prioridad = "BAJA")
        ))
        catalogoDao.insertEstados(listOf(
            EstadoRecordatorioEntity(nombre_estado = "PENDIENTE"),
            EstadoRecordatorioEntity(nombre_estado = "REALIZADO")
        ))
        catalogoDao.insertRecurrencias(listOf(
            RecurrenciaEntity(nombre_recurrencia = "NINGUNA"),
            RecurrenciaEntity(nombre_recurrencia = "DIARIA"),
            RecurrenciaEntity(nombre_recurrencia = "SEMANAL"),
            RecurrenciaEntity(nombre_recurrencia = "MENSUAL")
        ))

        val demoUser = usuarioDao.login("demo@demo.com", "123456") ?: return

        val comida = categoriaDao.getIdByName("Comida") ?: 1
        val transporte = categoriaDao.getIdByName("Transporte") ?: 2
        val servicios = categoriaDao.getIdByName("Servicios") ?: 3
        val ocio = categoriaDao.getIdByName("Ocio") ?: 4
        val hogar = categoriaDao.getIdByName("Hogar") ?: 5

        listOf(
            GastoEntity(id_usuario = demoUser.id_usuario, id_categoria = comida, titulo = "Almuerzo ejecutivo", monto = 22.5, fecha = "2026-04-01"),
            GastoEntity(id_usuario = demoUser.id_usuario, id_categoria = transporte, titulo = "Taxi oficina", monto = 18.0, fecha = "2026-04-02"),
            GastoEntity(id_usuario = demoUser.id_usuario, id_categoria = servicios, titulo = "Internet hogar", monto = 65.0, fecha = "2026-04-03"),
            GastoEntity(id_usuario = demoUser.id_usuario, id_categoria = comida, titulo = "Cena", monto = 32.0, fecha = "2026-04-04"),
            GastoEntity(id_usuario = demoUser.id_usuario, id_categoria = ocio, titulo = "Café reunión", monto = 11.5, fecha = "2026-04-05"),
            GastoEntity(id_usuario = demoUser.id_usuario, id_categoria = hogar, titulo = "Supermercado", monto = 86.0, fecha = "2026-04-06"),
            GastoEntity(id_usuario = demoUser.id_usuario, id_categoria = transporte, titulo = "Bus", monto = 6.0, fecha = "2026-04-07")
        ).forEach { gastoDao.insert(it) }

        val h1 = habitoDao.insert(HabitoEntity(id_usuario = demoUser.id_usuario, nombre_habito = "Tomar agua")).toInt()
        val h2 = habitoDao.insert(HabitoEntity(id_usuario = demoUser.id_usuario, nombre_habito = "Leer 20 min")).toInt()
        val h3 = habitoDao.insert(HabitoEntity(id_usuario = demoUser.id_usuario, nombre_habito = "Caminar")).toInt()
        val h4 = habitoDao.insert(HabitoEntity(id_usuario = demoUser.id_usuario, nombre_habito = "Planificar día")).toInt()
        val h5 = habitoDao.insert(HabitoEntity(id_usuario = demoUser.id_usuario, nombre_habito = "Dormir temprano")).toInt()

        val today = today()
        listOf(
            SeguimientoHabitoEntity(id_habito = h1, fecha = today, completado = true),
            SeguimientoHabitoEntity(id_habito = h2, fecha = today, completado = false),
            SeguimientoHabitoEntity(id_habito = h3, fecha = today, completado = true),
            SeguimientoHabitoEntity(id_habito = h4, fecha = today, completado = true),
            SeguimientoHabitoEntity(id_habito = h5, fecha = today, completado = false)
        ).forEach { habitoDao.upsertTracking(it) }

        val tipoGeo = catalogoDao.getTipoId("GEO") ?: 2
        val tipoHora = catalogoDao.getTipoId("HORA") ?: 1
        val prioridadAlta = catalogoDao.getPrioridadId("ALTA") ?: 1
        val prioridadMedia = catalogoDao.getPrioridadId("MEDIA") ?: 2
        val estadoPendiente = catalogoDao.getEstadoId("PENDIENTE") ?: 1
        val recDiaria = catalogoDao.getRecurrenciaId("DIARIA") ?: 2
        val recSemanal = catalogoDao.getRecurrenciaId("SEMANAL") ?: 3
        val recMensual = catalogoDao.getRecurrenciaId("MENSUAL") ?: 4

        listOf(
            RecordatorioEntity(id_usuario = demoUser.id_usuario, titulo = "Comprar pan", nota = "Cerca a la panadería", id_tipo = tipoGeo, id_prioridad = prioridadMedia, id_estado = estadoPendiente, id_recurrencia = recDiaria, lugar = "Panadería", radio = 200, latitud = -12.0464, longitud = -77.0428),
            RecordatorioEntity(id_usuario = demoUser.id_usuario, titulo = "Pagar recibo", nota = "Antes de las 6pm", id_tipo = tipoHora, id_prioridad = prioridadAlta, id_estado = estadoPendiente, id_recurrencia = recMensual, lugar = "", radio = 150, latitud = null, longitud = null),
            RecordatorioEntity(id_usuario = demoUser.id_usuario, titulo = "Recoger pedido", nota = "Cuando llegues al centro comercial", id_tipo = tipoGeo, id_prioridad = prioridadAlta, id_estado = estadoPendiente, id_recurrencia = recSemanal, lugar = "Centro Comercial", radio = 250, latitud = -12.0500, longitud = -77.0300)
        ).forEach { recordatorioDao.insert(it) }
    }

    suspend fun login(correo: String, clave: String): UserUi? =
        usuarioDao.login(correo, clave)?.let { UserUi(it.id_usuario, it.nombre, it.correo) }

    suspend fun getDashboard(userId: Int): DashboardUi {
        val total = gastoDao.totalByUser(userId)
        val countGastos = gastoDao.countByUser(userId)
        val promedio = if (countGastos > 0) total / countGastos else 0.0
        val habitos = habitoDao.countByUser(userId)
        val habitosCumplidos = habitoDao.completedTodayByUser(userId, today())
        val activos = recordatorioDao.activeCountByUser(userId)
        val geo = recordatorioDao.activeGeoCountByUser(userId)

        return DashboardUi(
            totalGastos = total,
            promedioDiario = promedio,
            proyeccionMensual = promedio * 30,
            habitosActivos = habitos,
            habitosCumplidos = habitosCumplidos,
            recordatoriosActivos = activos,
            recordatoriosGeo = geo
        )
    }

    suspend fun getExpenses(userId: Int): List<ExpenseUi> = gastoDao.getUiByUser(userId)
    suspend fun getHabits(userId: Int): List<HabitUi> = habitoDao.getUiByUser(userId, today())
    suspend fun getReminders(userId: Int): List<ReminderUi> = recordatorioDao.getUiByUser(userId)
    suspend fun getCategoryTotals(userId: Int): List<CategoryAmount> = gastoDao.totalsByCategory(userId)

    suspend fun addExpense(userId: Int, titulo: String, monto: Double, categoria: String, fecha: String) {
        val categoriaId = categoriaDao.getIdByName(categoria) ?: run {
            categoriaDao.insertAll(listOf(CategoriaGastoEntity(nombre_categoria = categoria)))
            categoriaDao.getIdByName(categoria) ?: 1
        }
        gastoDao.insert(
            GastoEntity(
                id_usuario = userId,
                id_categoria = categoriaId,
                titulo = titulo,
                monto = monto,
                fecha = fecha
            )
        )
    }

    suspend fun updateExpense(id: Int, titulo: String, monto: Double, categoria: String, fecha: String) {
        val current = gastoDao.getById(id) ?: return
        val categoriaId = categoriaDao.getIdByName(categoria) ?: run {
            categoriaDao.insertAll(listOf(CategoriaGastoEntity(nombre_categoria = categoria)))
            categoriaDao.getIdByName(categoria) ?: current.id_categoria
        }
        gastoDao.update(current.copy(titulo = titulo, monto = monto, id_categoria = categoriaId, fecha = fecha))
    }

    suspend fun deleteExpense(id: Int) = gastoDao.deleteById(id)

    suspend fun addHabit(userId: Int, nombre: String) {
        habitoDao.insert(HabitoEntity(id_usuario = userId, nombre_habito = nombre))
    }

    suspend fun updateHabit(id: Int, nombre: String) {
        val item = habitoDao.getById(id) ?: return
        habitoDao.update(item.copy(nombre_habito = nombre))
    }

    suspend fun toggleHabit(id: Int) {
        val current = habitoDao.getTrackingByDate(id, today())
        val nextState = !(current?.completado ?: false)
        habitoDao.upsertTracking(
            SeguimientoHabitoEntity(
                id_seguimiento = current?.id_seguimiento ?: 0,
                id_habito = id,
                fecha = today(),
                completado = nextState
            )
        )
    }

    suspend fun deleteHabit(id: Int) = habitoDao.deleteById(id)

    suspend fun addReminder(
        userId: Int,
        titulo: String,
        nota: String,
        tipo: String,
        lugar: String,
        radius: Int,
        prioridad: String,
        recurrencia: String,
        latitud: Double?,
        longitud: Double?
    ) {
        val tipoId = catalogoDao.getTipoId(tipo) ?: 1
        val prioridadId = catalogoDao.getPrioridadId(prioridad) ?: 2
        val estadoId = catalogoDao.getEstadoId("PENDIENTE") ?: 1
        val recurrenciaId = catalogoDao.getRecurrenciaId(recurrencia) ?: 1

        recordatorioDao.insert(
            RecordatorioEntity(
                id_usuario = userId,
                titulo = titulo,
                nota = nota,
                id_tipo = tipoId,
                id_prioridad = prioridadId,
                id_estado = estadoId,
                id_recurrencia = recurrenciaId,
                lugar = lugar,
                radio = radius,
                latitud = latitud,
                longitud = longitud
            )
        )
    }

    suspend fun updateReminder(
        id: Int,
        titulo: String,
        nota: String,
        tipo: String,
        lugar: String,
        radius: Int,
        prioridad: String,
        estado: String,
        recurrencia: String,
        latitud: Double?,
        longitud: Double?
    ) {
        val current = recordatorioDao.getById(id) ?: return
        val tipoId = catalogoDao.getTipoId(tipo) ?: current.id_tipo
        val prioridadId = catalogoDao.getPrioridadId(prioridad) ?: current.id_prioridad
        val estadoId = catalogoDao.getEstadoId(estado) ?: current.id_estado
        val recurrenciaId = catalogoDao.getRecurrenciaId(recurrencia) ?: current.id_recurrencia

        recordatorioDao.update(
            current.copy(
                titulo = titulo,
                nota = nota,
                id_tipo = tipoId,
                id_prioridad = prioridadId,
                id_estado = estadoId,
                id_recurrencia = recurrenciaId,
                lugar = lugar,
                radio = radius,
                latitud = latitud,
                longitud = longitud
            )
        )
    }

    suspend fun toggleReminderStatus(id: Int) {
        val current = recordatorioDao.getById(id) ?: return
        val pendienteId = catalogoDao.getEstadoId("PENDIENTE") ?: current.id_estado
        val realizadoId = catalogoDao.getEstadoId("REALIZADO") ?: current.id_estado
        val next = if (current.id_estado == pendienteId) realizadoId else pendienteId
        recordatorioDao.update(current.copy(id_estado = next))
    }

    suspend fun deleteReminder(id: Int) = recordatorioDao.deleteById(id)

    private fun today(): String = LocalDate.now().toString()
}
