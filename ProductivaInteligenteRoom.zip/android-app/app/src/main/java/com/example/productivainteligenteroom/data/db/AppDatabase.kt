package com.example.productivainteligenteroom.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.productivainteligenteroom.data.db.dao.CatalogoRecordatorioDao
import com.example.productivainteligenteroom.data.db.dao.CategoriaGastoDao
import com.example.productivainteligenteroom.data.db.dao.GastoDao
import com.example.productivainteligenteroom.data.db.dao.HabitoDao
import com.example.productivainteligenteroom.data.db.dao.RecordatorioDao
import com.example.productivainteligenteroom.data.db.dao.UsuarioDao
import com.example.productivainteligenteroom.data.db.entities.CategoriaGastoEntity
import com.example.productivainteligenteroom.data.db.entities.EstadoRecordatorioEntity
import com.example.productivainteligenteroom.data.db.entities.GastoEntity
import com.example.productivainteligenteroom.data.db.entities.HabitoEntity
import com.example.productivainteligenteroom.data.db.entities.PrioridadEntity
import com.example.productivainteligenteroom.data.db.entities.RecordatorioEntity
import com.example.productivainteligenteroom.data.db.entities.RecurrenciaEntity
import com.example.productivainteligenteroom.data.db.entities.SeguimientoHabitoEntity
import com.example.productivainteligenteroom.data.db.entities.TipoRecordatorioEntity
import com.example.productivainteligenteroom.data.db.entities.UsuarioEntity

@Database(
    entities = [
        UsuarioEntity::class,
        CategoriaGastoEntity::class,
        GastoEntity::class,
        HabitoEntity::class,
        SeguimientoHabitoEntity::class,
        TipoRecordatorioEntity::class,
        PrioridadEntity::class,
        EstadoRecordatorioEntity::class,
        RecurrenciaEntity::class,
        RecordatorioEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun usuarioDao(): UsuarioDao
    abstract fun categoriaGastoDao(): CategoriaGastoDao
    abstract fun gastoDao(): GastoDao
    abstract fun habitoDao(): HabitoDao
    abstract fun catalogoRecordatorioDao(): CatalogoRecordatorioDao
    abstract fun recordatorioDao(): RecordatorioDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "productiva_room.db"
                ).fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
