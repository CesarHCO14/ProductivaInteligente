package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "categorias_gasto",
    indices = [Index(value = ["nombre_categoria"], unique = true)]
)
data class CategoriaGastoEntity(
    @PrimaryKey(autoGenerate = true) val id_categoria: Int = 0,
    val nombre_categoria: String
)
