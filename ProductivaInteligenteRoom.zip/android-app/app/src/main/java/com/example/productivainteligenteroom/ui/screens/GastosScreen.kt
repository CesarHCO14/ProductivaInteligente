package com.example.productivainteligenteroom.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.ui.components.EmptyState
import com.example.productivainteligenteroom.ui.components.KpiCard
import com.example.productivainteligenteroom.vm.MainViewModel

@Composable
fun GastosScreen(vm: MainViewModel) {
    var titulo by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf("") }
    var editId by remember { mutableStateOf<Int?>(null) }
    var deleteId by remember { mutableStateOf<Int?>(null) }
    var showForm by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.refreshAll() }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Gestión de gastos", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)

        OutlinedTextField(
            value = vm.searchQuery.value,
            onValueChange = { vm.searchQuery.value = it },
            label = { Text("Buscar gasto o categoría") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        KpiCard(
            "Gasto acumulado",
            "S/ %.2f".format(vm.dashboard.value.totalGastos),
            "Categoría top: ${vm.categoryTotals().firstOrNull()?.categoria ?: "Sin datos"}"
        )

        Button(onClick = { showForm = !showForm }, modifier = Modifier.fillMaxWidth()) {
            Icon(if (showForm) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(if (showForm) "Ocultar formulario" else if (editId != null) "Editar gasto" else "Nuevo gasto")
        }

        if (showForm) {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = titulo, onValueChange = { titulo = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = monto, onValueChange = { monto = it }, label = { Text("Monto") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = categoria, onValueChange = { categoria = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                    Button(onClick = {
                        val m = monto.toDoubleOrNull() ?: return@Button
                        if (editId == null) vm.addExpense(titulo.ifBlank { "Gasto" }, m, categoria.ifBlank { "General" })
                        else vm.updateExpense(editId!!, titulo.ifBlank { "Gasto" }, m, categoria.ifBlank { "General" })
                        titulo = ""; monto = ""; categoria = ""; editId = null; showForm = false
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (editId == null) "Guardar gasto" else "Actualizar gasto")
                    }
                }
            }
        }

        Text("Lista de gastos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        val items = vm.filteredExpenses()
        if (items.isEmpty()) {
            EmptyState("No hay gastos")
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items) { gasto ->
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(gasto.titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("S/ %.2f".format(gasto.monto), style = MaterialTheme.typography.bodyLarge)
                            Text("${gasto.categoria} • ${gasto.fecha}", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = {
                                    editId = gasto.id
                                    titulo = gasto.titulo
                                    monto = gasto.monto.toString()
                                    categoria = gasto.categoria
                                    showForm = true
                                }) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(4.dp)); Text("Editar") }
                                TextButton(onClick = { deleteId = gasto.id }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Eliminar") }
                            }
                        }
                    }
                }
            }
        }
    }

    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            confirmButton = { TextButton(onClick = { vm.deleteExpense(id); deleteId = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancelar") } },
            title = { Text("Confirmar eliminación") },
            text = { Text("¿Eliminar gasto?") }
        )
    }
}
