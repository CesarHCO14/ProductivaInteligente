package com.example.productivainteligenteroom.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.ui.components.EmptyState
import com.example.productivainteligenteroom.ui.components.KpiCard
import com.example.productivainteligenteroom.vm.MainViewModel
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GastosScreen(vm: MainViewModel) {
    var titulo by remember { mutableStateOf("") }
    var monto by remember { mutableStateOf("") }
    var fecha by remember { mutableStateOf(LocalDate.now().toString()) }
    var categoria by remember { mutableStateOf("") }
    var categoriaExpanded by remember { mutableStateOf(false) }
    var filterCategoriaExpanded by remember { mutableStateOf(false) }
    var ordenExpanded by remember { mutableStateOf(false) }
    var editId by remember { mutableStateOf<Int?>(null) }
    var deleteId by remember { mutableStateOf<Int?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var showFilters by remember { mutableStateOf(false) }

    var inicioFiltro by remember { mutableStateOf(vm.filterStartDate.value) }
    var finFiltro by remember { mutableStateOf(vm.filterEndDate.value) }
    var categoriaFiltro by remember { mutableStateOf(vm.filterCategory.value) }
    var mesFiltro by remember { mutableStateOf(vm.filterMonth.value) }
    var minFiltro by remember { mutableStateOf(vm.filterAmountMin.value) }
    var maxFiltro by remember { mutableStateOf(vm.filterAmountMax.value) }
    var ordenFiltro by remember { mutableStateOf(vm.filterOrder.value) }

    val ordenes = listOf(
        "fecha_desc" to "Fecha reciente",
        "fecha_asc" to "Fecha antigua",
        "monto_desc" to "Monto mayor",
        "monto_asc" to "Monto menor",
        "categoria_asc" to "Categoría A-Z"
    )

    LaunchedEffect(Unit) { vm.refreshAll() }
    LaunchedEffect(vm.categories.value) {
        if (categoria.isBlank()) categoria = vm.categories.value.firstOrNull() ?: "Comida"
    }

    val items = vm.filteredExpenses()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "Gestión de gastos",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold
        )

        OutlinedTextField(
            value = vm.searchQuery.value,
            onValueChange = { vm.searchQuery.value = it },
            label = { Text("Buscar gasto o categoría") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                KpiCard(
                    "Gasto acumulado",
                    "S/ %.2f".format(vm.dashboard.value.totalGastos),
                    "Categoría top: ${vm.categoryTotals().firstOrNull()?.categoria ?: "Sin datos"}"
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { showForm = !showForm }, modifier = Modifier.weight(1f)) {
                        Icon(if (showForm) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (showForm) "Ocultar" else "Nuevo gasto")
                    }

                    OutlinedButton(onClick = { showFilters = !showFilters }, modifier = Modifier.weight(1f)) {
                        Text(if (showFilters) "Ocultar filtros" else "Filtros avanzados")
                    }
                }
            }

            if (showFilters) {
                item {
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Filtros avanzados", fontWeight = FontWeight.SemiBold)

                            OutlinedTextField(
                                value = inicioFiltro,
                                onValueChange = { inicioFiltro = it.trim() },
                                label = { Text("Fecha inicio: yyyy-MM-dd") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = finFiltro,
                                onValueChange = { finFiltro = it.trim() },
                                label = { Text("Fecha fin: yyyy-MM-dd") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = mesFiltro,
                                onValueChange = { mesFiltro = it.trim() },
                                label = { Text("Mes: yyyy-MM") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            ExposedDropdownMenuBox(
                                expanded = filterCategoriaExpanded,
                                onExpandedChange = { filterCategoriaExpanded = !filterCategoriaExpanded }
                            ) {
                                OutlinedTextField(
                                    value = if (categoriaFiltro.isBlank()) "Todas" else categoriaFiltro,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Categoría") },
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = filterCategoriaExpanded) },
                                    singleLine = true
                                )

                                ExposedDropdownMenu(
                                    expanded = filterCategoriaExpanded,
                                    onDismissRequest = { filterCategoriaExpanded = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Todas") },
                                        onClick = {
                                            categoriaFiltro = ""
                                            filterCategoriaExpanded = false
                                        }
                                    )
                                    vm.categories.value.forEach { item ->
                                        DropdownMenuItem(
                                            text = { Text(item) },
                                            onClick = {
                                                categoriaFiltro = item
                                                filterCategoriaExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = minFiltro,
                                    onValueChange = { minFiltro = it.trim() },
                                    label = { Text("Monto mínimo") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = maxFiltro,
                                    onValueChange = { maxFiltro = it.trim() },
                                    label = { Text("Monto máximo") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }

                            ExposedDropdownMenuBox(
                                expanded = ordenExpanded,
                                onExpandedChange = { ordenExpanded = !ordenExpanded }
                            ) {
                                OutlinedTextField(
                                    value = ordenes.firstOrNull { it.first == ordenFiltro }?.second ?: "Fecha reciente",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Ordenar por") },
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = ordenExpanded) },
                                    singleLine = true
                                )

                                ExposedDropdownMenu(
                                    expanded = ordenExpanded,
                                    onDismissRequest = { ordenExpanded = false }
                                ) {
                                    ordenes.forEach { (value, label) ->
                                        DropdownMenuItem(
                                            text = { Text(label) },
                                            onClick = {
                                                ordenFiltro = value
                                                ordenExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        vm.applyAdvancedExpenseFilters(
                                            inicio = inicioFiltro,
                                            fin = finFiltro,
                                            categoria = categoriaFiltro,
                                            mes = mesFiltro,
                                            min = minFiltro,
                                            max = maxFiltro,
                                            orden = ordenFiltro
                                        )
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Aplicar") }

                                OutlinedButton(
                                    onClick = {
                                        inicioFiltro = ""
                                        finFiltro = ""
                                        categoriaFiltro = ""
                                        mesFiltro = ""
                                        minFiltro = ""
                                        maxFiltro = ""
                                        ordenFiltro = "fecha_desc"
                                        vm.clearExpenseFilters()
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Limpiar") }
                            }
                        }
                    }
                }
            }

            if (showForm) {
                item {
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(value = titulo, onValueChange = { titulo = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = monto, onValueChange = { monto = it }, label = { Text("Monto") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = fecha, onValueChange = { fecha = it.trim() }, label = { Text("Fecha: yyyy-MM-dd") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                            ExposedDropdownMenuBox(
                                expanded = categoriaExpanded,
                                onExpandedChange = { categoriaExpanded = !categoriaExpanded }
                            ) {
                                OutlinedTextField(
                                    value = categoria,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Categoría desde tabla relacional") },
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoriaExpanded) },
                                    singleLine = true
                                )

                                ExposedDropdownMenu(
                                    expanded = categoriaExpanded,
                                    onDismissRequest = { categoriaExpanded = false }
                                ) {
                                    vm.categories.value.forEach { item ->
                                        DropdownMenuItem(
                                            text = { Text(item) },
                                            onClick = {
                                                categoria = item
                                                categoriaExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    val m = monto.toDoubleOrNull() ?: return@Button
                                    if (editId == null) {
                                        vm.addExpense(titulo.ifBlank { "Gasto" }, m, categoria.ifBlank { "General" }, fecha)
                                    } else {
                                        vm.updateExpense(editId!!, titulo.ifBlank { "Gasto" }, m, categoria.ifBlank { "General" }, fecha)
                                    }
                                    titulo = ""
                                    monto = ""
                                    fecha = LocalDate.now().toString()
                                    editId = null
                                    showForm = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (editId == null) "Guardar gasto" else "Actualizar gasto")
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "Lista de gastos (${items.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (items.isEmpty()) {
                item { EmptyState("No hay gastos para mostrar") }
            } else {
                items(items) { gasto ->
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(gasto.titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("S/ %.2f".format(gasto.monto), style = MaterialTheme.typography.bodyLarge)
                            Text("${gasto.categoria} • ${gasto.fecha}", style = MaterialTheme.typography.bodySmall)
                            Text("Relación: gastos.id_categoria → categorias_gasto.id_categoria", style = MaterialTheme.typography.labelSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = {
                                    editId = gasto.id
                                    titulo = gasto.titulo
                                    monto = gasto.monto.toString()
                                    fecha = gasto.fecha
                                    categoria = gasto.categoria
                                    showForm = true
                                }) {
                                    Icon(Icons.Default.Edit, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("Editar")
                                }

                                TextButton(onClick = { deleteId = gasto.id }) {
                                    Icon(Icons.Default.Delete, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("Eliminar")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            confirmButton = { TextButton(onClick = { vm.deleteExpense(id); deleteId = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancelar") } },
            title = { Text("Confirmar eliminación") },
            text = { Text("¿Eliminar gasto?") }
        )
    }
}
