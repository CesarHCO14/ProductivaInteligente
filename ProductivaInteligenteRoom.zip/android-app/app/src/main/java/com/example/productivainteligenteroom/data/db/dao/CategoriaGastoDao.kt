package com.example.productivainteligenteroom.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RewriteQueriesToDropUnusedColumns
import com.example.productivainteligenteroom.data.db.entities.CategoriaGastoEntity

@Dao
@RewriteQueriesToDropUnusedColumns
interface CategoriaGastoDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<CategoriaGastoEntity>)

    @Query("SELECT id_categoria FROM categorias_gasto WHERE nombre_categoria = :nombre LIMIT 1")
    suspend fun getIdByName(nombre: String): Int?

    @Query("SELECT COUNT(*) FROM categorias_gasto")
    suspend fun count(): Int
}
