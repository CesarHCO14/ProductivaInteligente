package com.example.productivainteligenteroom.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.productivainteligenteroom.data.db.entities.CategoriaGastoEntity

@Dao
interface CategoriaGastoDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<CategoriaGastoEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: CategoriaGastoEntity): Long

    @Query("SELECT id_categoria FROM categorias_gasto WHERE nombre_categoria = :nombre LIMIT 1")
    suspend fun getIdByName(nombre: String): Int?

    @Query("SELECT nombre_categoria FROM categorias_gasto ORDER BY nombre_categoria ASC")
    suspend fun listNames(): List<String>

    @Query("SELECT COUNT(*) FROM categorias_gasto")
    suspend fun count(): Int
}
