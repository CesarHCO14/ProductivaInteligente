package com.example.productivainteligenteroom.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CorporateColors = lightColorScheme(
    primary = Color(0xFF2D5BFF),
    onPrimary = Color.White,
    secondary = Color(0xFF00A896),
    tertiary = Color(0xFFFFB703),
    background = Color(0xFFF4F7FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFEAF0FF),
    onSurfaceVariant = Color(0xFF64748B)
)

@Composable
fun ProductivaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CorporateColors,
        typography = Typography(),
        content = content
    )
}
