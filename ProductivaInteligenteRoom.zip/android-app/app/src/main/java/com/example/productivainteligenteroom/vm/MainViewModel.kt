package com.example.productivainteligenteroom.vm

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.productivainteligenteroom.data.db.models.CategoryAmount
import com.example.productivainteligenteroom.data.db.models.DashboardUi
import com.example.productivainteligenteroom.data.db.models.ExpenseUi
import com.example.productivainteligenteroom.data.db.models.HabitUi
import com.example.productivainteligenteroom.data.db.models.ReminderUi
import com.example.productivainteligenteroom.data.db.models.UserUi
import com.example.productivainteligenteroom.repository.AppRepository
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.roundToInt

class MainViewModel(private val appContext: Context? = null) : ViewModel() {
    private val repository by lazy { AppRepository(requireNotNull(appContext)) }

    val isLoggedIn = mutableStateOf(false)
    val user = mutableStateOf(UserUi())
    val dashboard = mutableStateOf(DashboardUi())
    val expenses = mutableStateOf(listOf<ExpenseUi>())
    val habits = mutableStateOf(listOf<HabitUi>())
    val reminders = mutableStateOf(listOf<ReminderUi>())
    val searchQuery = mutableStateOf("")
    val lastLatLng = mutableStateOf<Pair<Double, Double>?>(null)
    val statusMessage = mutableStateOf("")

    fun init() {
        if (appContext == null) return
        viewModelScope.launch {
            repository.seedDatabase()
            loadSession(appContext)
        }
    }

    fun loadSession(context: Context) {
        val prefs = context.getSharedPreferences("pi_room_session", Context.MODE_PRIVATE)
        val logged = prefs.getBoolean("logged", false)
        val correo = prefs.getString("correo", "") ?: ""
        if (logged && correo.isNotBlank()) {
            viewModelScope.launch {
                val sessionUser = repository.login(correo, "123456")
                if (sessionUser != null) {
                    user.value = sessionUser
                    isLoggedIn.value = true
                    refreshAll()
                }
            }
        }
    }

    fun login(context: Context, correo: String, clave: String) {
        viewModelScope.launch {
            val sessionUser = repository.login(correo, clave)
            if (sessionUser != null) {
                user.value = sessionUser
                isLoggedIn.value = true
                statusMessage.value = ""
                context.getSharedPreferences("pi_room_session", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("logged", true)
                    .putString("correo", correo)
                    .apply()
                refreshAll()
            } else {
                statusMessage.value = "Credenciales incorrectas"
            }
        }
    }

    fun logout(context: Context) {
        context.getSharedPreferences("pi_room_session", Context.MODE_PRIVATE)
            .edit().clear().apply()
        isLoggedIn.value = false
        user.value = UserUi()
        searchQuery.value = ""
    }

    fun refreshAll() {
        val userId = user.value.id
        if (userId <= 0) return
        viewModelScope.launch {
            dashboard.value = repository.getDashboard(userId)
            expenses.value = repository.getExpenses(userId)
            habits.value = repository.getHabits(userId)
            reminders.value = repository.getReminders(userId)
        }
    }

    fun addExpense(titulo: String, monto: Double, categoria: String) {
        viewModelScope.launch {
            repository.addExpense(user.value.id, titulo, monto, categoria, LocalDate.now().toString())
            refreshAll()
        }
    }

    fun updateExpense(id: Int, titulo: String, monto: Double, categoria: String) {
        viewModelScope.launch {
            repository.updateExpense(id, titulo, monto, categoria, LocalDate.now().toString())
            refreshAll()
        }
    }

    fun deleteExpense(id: Int) {
        viewModelScope.launch {
            repository.deleteExpense(id)
            refreshAll()
        }
    }

    fun addHabit(nombre: String) {
        viewModelScope.launch {
            repository.addHabit(user.value.id, nombre)
            refreshAll()
        }
    }

    fun updateHabit(id: Int, nombre: String) {
        viewModelScope.launch {
            repository.updateHabit(id, nombre)
            refreshAll()
        }
    }

    fun toggleHabit(id: Int) {
        viewModelScope.launch {
            repository.toggleHabit(id)
            refreshAll()
        }
    }

    fun deleteHabit(id: Int) {
        viewModelScope.launch {
            repository.deleteHabit(id)
            refreshAll()
        }
    }

    fun addReminder(
        titulo: String,
        nota: String,
        usarGeo: Boolean,
        lugar: String,
        radius: Int,
        prioridad: String,
        recurrencia: String
    ) {
        viewModelScope.launch {
            val coords = lastLatLng.value
            repository.addReminder(
                userId = user.value.id,
                titulo = titulo,
                nota = nota,
                tipo = if (usarGeo && coords != null) "GEO" else "HORA",
                lugar = lugar,
                radius = radius,
                prioridad = prioridad,
                recurrencia = recurrencia,
                latitud = coords?.first,
                longitud = coords?.second
            )
            refreshAll()
        }
    }

    fun updateReminder(
        id: Int,
        titulo: String,
        nota: String,
        lugar: String,
        radius: Int,
        prioridad: String,
        recurrencia: String,
        tipo: String,
        estado: String,
        latitud: Double?,
        longitud: Double?
    ) {
        viewModelScope.launch {
            repository.updateReminder(id, titulo, nota, tipo, lugar, radius, prioridad, estado, recurrencia, latitud, longitud)
            refreshAll()
        }
    }

    fun toggleReminderStatus(id: Int) {
        viewModelScope.launch {
            repository.toggleReminderStatus(id)
            refreshAll()
        }
    }

    fun deleteReminder(id: Int) {
        viewModelScope.launch {
            repository.deleteReminder(id)
            refreshAll()
        }
    }

    @SuppressLint("MissingPermission")
    fun captureLocation(context: Context) {
        val fine = ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED && coarse != PackageManager.PERMISSION_GRANTED) return
        val client = LocationServices.getFusedLocationProviderClient(context)
        client.lastLocation.addOnSuccessListener { location ->
            if (location != null) lastLatLng.value = location.latitude to location.longitude
        }
    }

    fun filteredExpenses(): List<ExpenseUi> =
        expenses.value.filter {
            searchQuery.value.isBlank() ||
                it.titulo.contains(searchQuery.value, true) ||
                it.categoria.contains(searchQuery.value, true)
        }

    fun filteredHabits(): List<HabitUi> =
        habits.value.filter {
            searchQuery.value.isBlank() || it.nombre.contains(searchQuery.value, true)
        }

    fun filteredReminders(): List<ReminderUi> =
        reminders.value.filter {
            searchQuery.value.isBlank() ||
                it.titulo.contains(searchQuery.value, true) ||
                it.lugar.contains(searchQuery.value, true)
        }

    fun categoryTotals(): List<CategoryAmount> = expenses.value
        .groupBy { it.categoria }
        .map { CategoryAmount(it.key, it.value.sumOf { e -> e.monto }) }
        .sortedByDescending { it.total }

    fun productivityPercent(): Int {
        if (dashboard.value.habitosActivos == 0) return 0
        return ((dashboard.value.habitosCumplidos.toFloat() / dashboard.value.habitosActivos) * 100).roundToInt()
    }

    fun shareReportIntent(context: Context): Intent {
        val d = dashboard.value
        val text = """
            PRODUCTIVA INTELIGENTE - REPORTE LOCAL
            Usuario: ${user.value.correo}
            Total gastos: S/ ${"%.2f".format(d.totalGastos)}
            Promedio diario: S/ ${"%.2f".format(d.promedioDiario)}
            Proyección mensual: S/ ${"%.2f".format(d.proyeccionMensual)}
            Productividad: ${productivityPercent()}%
            Recordatorios activos: ${d.recordatoriosActivos}
            Recordatorios GEO: ${d.recordatoriosGeo}
        """.trimIndent()

        return Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
    }
}
