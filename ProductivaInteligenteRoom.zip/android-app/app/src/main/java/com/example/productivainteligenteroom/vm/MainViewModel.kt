package com.example.productivainteligenteroom.vm

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.productivainteligenteroom.data.db.models.CategoryAmount
import com.example.productivainteligenteroom.data.db.models.DashboardUi
import com.example.productivainteligenteroom.data.db.models.ExpenseUi
import com.example.productivainteligenteroom.data.db.models.HabitUi
import com.example.productivainteligenteroom.data.db.models.ReminderUi
import com.example.productivainteligenteroom.data.db.models.UserUi
import com.example.productivainteligenteroom.notifications.NotificationHelper
import com.example.productivainteligenteroom.repository.AppRepository
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.roundToInt

class MainViewModel(private val appContext: Context? = null) : ViewModel() {
    private val repository by lazy { AppRepository(requireNotNull(appContext)) }

    val isLoggedIn = mutableStateOf(false)
    val user = mutableStateOf(UserUi())
    val dashboard = mutableStateOf(DashboardUi())
    val expenses = mutableStateOf(listOf<ExpenseUi>())
    val habits = mutableStateOf(listOf<HabitUi>())
    val reminders = mutableStateOf(listOf<ReminderUi>())
    val categories = mutableStateOf(listOf<String>())
    val smartAlerts = mutableStateOf(listOf<String>())
    val searchQuery = mutableStateOf("")
    val lastLatLng = mutableStateOf<Pair<Double, Double>?>(null)
    val statusMessage = mutableStateOf("")
    val isRegisterMode = mutableStateOf(false)

    val filterStartDate = mutableStateOf("")
    val filterEndDate = mutableStateOf("")
    val filterCategory = mutableStateOf("")
    val filterMonth = mutableStateOf("")
    val filterAmountMin = mutableStateOf("")
    val filterAmountMax = mutableStateOf("")
    val filterOrder = mutableStateOf("fecha_desc")

    fun init() {
        if (appContext == null) return
        viewModelScope.launch {
            repository.seedDatabase()
            categories.value = repository.getCategories()
            loadSession(appContext)
        }
    }

    fun toggleRegisterMode() {
        isRegisterMode.value = !isRegisterMode.value
        statusMessage.value = ""
    }

    fun register(context: Context, nombre: String, correo: String, clave: String, confirmar: String) {
        viewModelScope.launch {
            if (nombre.isBlank() || correo.isBlank() || clave.isBlank()) {
                statusMessage.value = "Completa todos los campos"
                return@launch
            }
            if (clave != confirmar) {
                statusMessage.value = "Las claves no coinciden"
                return@launch
            }
            val result = repository.register(nombre, correo, clave)
            result.onSuccess {
                user.value = it
                isLoggedIn.value = true
                isRegisterMode.value = false
                statusMessage.value = ""
                context.getSharedPreferences("pi_room_session", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("logged", true)
                    .putString("correo", correo)
                    .putString("clave", clave)
                    .apply()
                refreshAll()
            }.onFailure {
                statusMessage.value = it.message ?: "No se pudo registrar"
            }
        }
    }

    fun loadSession(context: Context) {
        val prefs = context.getSharedPreferences("pi_room_session", Context.MODE_PRIVATE)
        val logged = prefs.getBoolean("logged", false)
        val correo = prefs.getString("correo", "") ?: ""
        val clave = prefs.getString("clave", "123456") ?: "123456"
        if (logged && correo.isNotBlank()) {
            viewModelScope.launch {
                val sessionUser = repository.login(correo, clave)
                if (sessionUser != null) {
                    user.value = sessionUser
                    isLoggedIn.value = true
                    refreshAll()
                }
            }
        }
    }

    fun login(context: Context, correo: String, clave: String) {
        viewModelScope.launch {
            val sessionUser = repository.login(correo, clave)
            if (sessionUser != null) {
                user.value = sessionUser
                isLoggedIn.value = true
                statusMessage.value = ""
                context.getSharedPreferences("pi_room_session", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("logged", true)
                    .putString("correo", correo)
                    .putString("clave", clave)
                    .apply()
                refreshAll()
            } else {
                statusMessage.value = "Credenciales incorrectas"
            }
        }
    }

    fun logout(context: Context) {
        context.getSharedPreferences("pi_room_session", Context.MODE_PRIVATE).edit().clear().apply()
        isLoggedIn.value = false
        user.value = UserUi()
        searchQuery.value = ""
    }

    fun refreshAll() {
        val userId = user.value.id
        if (userId <= 0) return
        viewModelScope.launch {
            dashboard.value = repository.getDashboard(userId)
            expenses.value = repository.getExpensesAdvanced(
                userId = userId,
                inicio = filterStartDate.value,
                fin = filterEndDate.value,
                categoria = filterCategory.value,
                mes = filterMonth.value,
                montoMin = filterAmountMin.value,
                montoMax = filterAmountMax.value,
                orden = filterOrder.value
            )
            habits.value = repository.getHabits(userId)
            reminders.value = repository.getReminders(userId)
            categories.value = repository.getCategories()
            smartAlerts.value = buildSmartAlerts()
        }
    }

    fun applyAdvancedExpenseFilters(
        inicio: String,
        fin: String,
        categoria: String,
        mes: String,
        min: String,
        max: String,
        orden: String
    ) {
        filterStartDate.value = inicio.trim()
        filterEndDate.value = fin.trim()
        filterCategory.value = categoria.trim()
        filterMonth.value = mes.trim()
        filterAmountMin.value = min.trim()
        filterAmountMax.value = max.trim()
        filterOrder.value = orden.trim().ifBlank { "fecha_desc" }
        refreshAll()
    }

    fun clearExpenseFilters() {
        filterStartDate.value = ""
        filterEndDate.value = ""
        filterCategory.value = ""
        filterMonth.value = ""
        filterAmountMin.value = ""
        filterAmountMax.value = ""
        filterOrder.value = "fecha_desc"
        refreshAll()
    }

    private suspend fun buildSmartAlerts(): List<String> {
        val alerts = mutableListOf<String>()
        val userId = user.value.id
        val promedio = repository.averageExpense(userId)

        val comidaTotal = repository.totalByCategory(userId, "Comida")
        if (comidaTotal > promedio && promedio > 0) {
            alerts.add("Tu gasto en comida supera el promedio general de gastos.")
        }

        val pendientesHabitos = habits.value.count { !it.completadoHoy }
        if (pendientesHabitos > 0) {
            alerts.add("Tienes $pendientesHabitos hábitos pendientes hoy.")
        }

        if (dashboard.value.avisosVencidos > 0) {
            alerts.add("Hay ${dashboard.value.avisosVencidos} recordatorios vencidos.")
        }

        if (dashboard.value.avisosProximos > 0) {
            alerts.add("Tienes ${dashboard.value.avisosProximos} avisos próximos en los siguientes 7 días.")
        }

        if (alerts.isEmpty()) {
            alerts.add("Todo está controlado por ahora.")
        }

        return alerts
    }

    fun addExpense(titulo: String, monto: Double, categoria: String, fecha: String) {
        viewModelScope.launch {
            repository.addExpense(user.value.id, titulo, monto, categoria, fecha.ifBlank { LocalDate.now().toString() })
            refreshAll()
        }
    }

    fun updateExpense(id: Int, titulo: String, monto: Double, categoria: String, fecha: String) {
        viewModelScope.launch {
            repository.updateExpense(id, titulo, monto, categoria, fecha.ifBlank { LocalDate.now().toString() })
            refreshAll()
        }
    }

    fun deleteExpense(id: Int) {
        viewModelScope.launch {
            repository.deleteExpense(id)
            refreshAll()
        }
    }

    fun addHabit(nombre: String) {
        viewModelScope.launch {
            repository.addHabit(user.value.id, nombre)
            refreshAll()
        }
    }

    fun updateHabit(id: Int, nombre: String) {
        viewModelScope.launch {
            repository.updateHabit(id, nombre)
            refreshAll()
        }
    }

    fun toggleHabit(id: Int) {
        viewModelScope.launch {
            repository.toggleHabit(id)
            refreshAll()
        }
    }

    fun deleteHabit(id: Int) {
        viewModelScope.launch {
            repository.deleteHabit(id)
            refreshAll()
        }
    }

    fun addReminder(
        context: Context,
        titulo: String,
        nota: String,
        usarGeo: Boolean,
        lugar: String,
        radius: Int,
        prioridad: String,
        recurrencia: String,
        fechaRecordatorio: String?,
        horaRecordatorio: String?
    ) {
        viewModelScope.launch {
            val coords = lastLatLng.value
            val id = repository.addReminder(
                userId = user.value.id,
                titulo = titulo,
                nota = nota,
                tipo = if (usarGeo && coords != null) "GEO" else "HORA",
                lugar = lugar,
                radius = radius,
                prioridad = prioridad,
                recurrencia = recurrencia,
                latitud = coords?.first,
                longitud = coords?.second,
                fechaRecordatorio = fechaRecordatorio,
                horaRecordatorio = horaRecordatorio
            )
            NotificationHelper.scheduleReminder(context, id, titulo, nota, fechaRecordatorio, horaRecordatorio)
            refreshAll()
        }
    }

    fun updateReminder(
        context: Context,
        id: Int,
        titulo: String,
        nota: String,
        lugar: String,
        radius: Int,
        prioridad: String,
        recurrencia: String,
        tipo: String,
        estado: String,
        latitud: Double?,
        longitud: Double?,
        fechaRecordatorio: String?,
        horaRecordatorio: String?
    ) {
        viewModelScope.launch {
            repository.updateReminder(id, titulo, nota, tipo, lugar, radius, prioridad, estado, recurrencia, latitud, longitud, fechaRecordatorio, horaRecordatorio)
            NotificationHelper.scheduleReminder(context, id, titulo, nota, fechaRecordatorio, horaRecordatorio)
            refreshAll()
        }
    }

    fun toggleReminderStatus(id: Int) {
        viewModelScope.launch {
            repository.toggleReminderStatus(id)
            refreshAll()
        }
    }

    fun deleteReminder(id: Int) {
        viewModelScope.launch {
            repository.deleteReminder(id)
            refreshAll()
        }
    }

    @SuppressLint("MissingPermission")
    fun captureLocation(context: Context) {
        val fine = ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED && coarse != PackageManager.PERMISSION_GRANTED) return
        val client = LocationServices.getFusedLocationProviderClient(context)
        client.lastLocation.addOnSuccessListener { location ->
            if (location != null) lastLatLng.value = location.latitude to location.longitude
        }
    }

    fun filteredExpenses(): List<ExpenseUi> =
        expenses.value.filter {
            searchQuery.value.isBlank() ||
                it.titulo.contains(searchQuery.value, true) ||
                it.categoria.contains(searchQuery.value, true)
        }

    fun filteredHabits(): List<HabitUi> =
        habits.value.filter {
            searchQuery.value.isBlank() || it.nombre.contains(searchQuery.value, true)
        }

    fun filteredReminders(): List<ReminderUi> =
        reminders.value.filter {
            searchQuery.value.isBlank() ||
                it.titulo.contains(searchQuery.value, true) ||
                it.lugar.contains(searchQuery.value, true)
        }

    fun categoryTotals(): List<CategoryAmount> = expenses.value
        .groupBy { it.categoria }
        .map { CategoryAmount(it.key, it.value.sumOf { e -> e.monto }) }
        .sortedByDescending { it.total }

    fun productivityPercent(): Int {
        if (dashboard.value.habitosActivos == 0) return 0
        return ((dashboard.value.habitosCumplidos.toFloat() / dashboard.value.habitosActivos) * 100).roundToInt()
    }

    fun shareReportIntent(context: Context): Intent {
        val d = dashboard.value
        val text = """
            PRODUCTIVA INTELIGENTE - REPORTE LOCAL
            Usuario: ${user.value.correo}
            Total gastos: S/ ${"%.2f".format(d.totalGastos)}
            Promedio diario: S/ ${"%.2f".format(d.promedioDiario)}
            Proyección mensual: S/ ${"%.2f".format(d.proyeccionMensual)}
            Productividad: ${productivityPercent()}%
            Recordatorios activos: ${d.recordatoriosActivos}
            Recordatorios GEO: ${d.recordatoriosGeo}
            Avisos vencidos: ${d.avisosVencidos}
            Avisos próximos: ${d.avisosProximos}
        """.trimIndent()

        return Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
    }
}
