package com.example.productivainteligenteroom.ui.charts

import android.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.productivainteligenteroom.data.db.models.CategoryAmount
import com.example.productivainteligenteroom.data.db.models.ExpenseUi
import com.example.productivainteligenteroom.data.db.models.HabitUi
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter

@Composable
fun ExpensesBarChart(data: List<CategoryAmount>, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            BarChart(context).apply {
                description.isEnabled = false
                legend.isEnabled = false
                axisRight.isEnabled = false
                setFitBars(true)
            }
        },
        update = { chart ->
            val entries = data.mapIndexed { index, item -> BarEntry(index.toFloat(), item.total.toFloat()) }
            val dataSet = BarDataSet(entries, "Gastos").apply {
                color = Color.rgb(45, 91, 255)
                valueTextColor = Color.DKGRAY
            }
            chart.xAxis.valueFormatter = IndexAxisValueFormatter(data.map { it.categoria })
            chart.xAxis.granularity = 1f
            chart.data = BarData(dataSet).apply { barWidth = 0.58f }
            chart.invalidate()
        }
    )
}

@Composable
fun ExpenseTrendLineChart(expenses: List<ExpenseUi>, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                axisRight.isEnabled = false
                legend.isEnabled = false
                setTouchEnabled(false)
            }
        },
        update = { chart ->
            val ordered = expenses.takeLast(7)
            val entries = ordered.mapIndexed { index, item -> Entry(index.toFloat(), item.monto.toFloat()) }
            val dataSet = LineDataSet(entries, "Tendencia").apply {
                color = Color.rgb(0, 168, 150)
                setCircleColor(Color.rgb(0, 168, 150))
                lineWidth = 2.8f
                valueTextColor = Color.DKGRAY
            }
            chart.xAxis.valueFormatter = IndexAxisValueFormatter(ordered.map { it.fecha.takeLast(2) })
            chart.xAxis.granularity = 1f
            chart.data = LineData(dataSet)
            chart.invalidate()
        }
    )
}

@Composable
fun HabitsPieChart(habits: List<HabitUi>, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            PieChart(context).apply {
                description.isEnabled = false
                isDrawHoleEnabled = true
                centerText = "Hábitos"
                setUsePercentValues(false)
            }
        },
        update = { chart ->
            val completed = habits.count { it.completadoHoy }
            val pending = habits.size - completed
            val entries = listOf(
                PieEntry(completed.toFloat(), "Completados"),
                PieEntry(pending.toFloat(), "Pendientes")
            )
            val dataSet = PieDataSet(entries, "Hábitos").apply {
                colors = listOf(Color.rgb(45, 91, 255), Color.rgb(255, 183, 3))
                valueTextColor = Color.BLACK
            }
            chart.data = PieData(dataSet)
            chart.invalidate()
        }
    )
}
