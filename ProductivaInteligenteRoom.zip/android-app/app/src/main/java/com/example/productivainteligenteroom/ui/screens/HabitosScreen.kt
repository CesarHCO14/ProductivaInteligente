package com.example.productivainteligenteroom.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.ui.components.EmptyState
import com.example.productivainteligenteroom.vm.MainViewModel

@Composable
fun HabitosScreen(vm: MainViewModel) {
    var nombre by remember { mutableStateOf("") }
    var editId by remember { mutableStateOf<Int?>(null) }
    var deleteId by remember { mutableStateOf<Int?>(null) }
    var showForm by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.refreshAll() }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Hábitos", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)

        OutlinedTextField(
            value = vm.searchQuery.value,
            onValueChange = { vm.searchQuery.value = it },
            label = { Text("Buscar hábito") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Button(onClick = { showForm = !showForm }, modifier = Modifier.fillMaxWidth()) {
            Icon(if (showForm) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(if (showForm) "Ocultar formulario" else if (editId != null) "Editar hábito" else "Nuevo hábito")
        }

        if (showForm) {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre del hábito") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = {
                        if (nombre.isNotBlank()) {
                            if (editId == null) vm.addHabit(nombre) else vm.updateHabit(editId!!, nombre)
                            nombre = ""; editId = null; showForm = false
                        }
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (editId == null) "Guardar hábito" else "Actualizar hábito")
                    }
                }
            }
        }

        Text("Lista de hábitos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        val items = vm.filteredHabits()
        if (items.isEmpty()) {
            EmptyState("No hay hábitos")
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items) { h ->
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(h.nombre, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text("Racha: ${h.racha}", style = MaterialTheme.typography.bodySmall)
                                Text(if (h.completadoHoy) "Estado: completado" else "Estado: pendiente", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = h.completadoHoy, onCheckedChange = { vm.toggleHabit(h.id) })
                            IconButton(onClick = { editId = h.id; nombre = h.nombre; showForm = true }) { Icon(Icons.Default.Edit, null) }
                            IconButton(onClick = { deleteId = h.id }) { Icon(Icons.Default.Delete, null) }
                        }
                    }
                }
            }
        }
    }

    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            confirmButton = { TextButton(onClick = { vm.deleteHabit(id); deleteId = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancelar") } },
            title = { Text("Confirmar eliminación") },
            text = { Text("¿Eliminar hábito?") }
        )
    }
}
