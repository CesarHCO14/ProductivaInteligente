package com.example.productivainteligenteroom.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RewriteQueriesToDropUnusedColumns
import androidx.room.Update
import com.example.productivainteligenteroom.data.db.entities.HabitoEntity
import com.example.productivainteligenteroom.data.db.entities.SeguimientoHabitoEntity
import com.example.productivainteligenteroom.data.db.models.HabitUi

@Dao
@RewriteQueriesToDropUnusedColumns
interface HabitoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(habito: HabitoEntity): Long

    @Update
    suspend fun update(habito: HabitoEntity)

    @Query("DELETE FROM habitos WHERE id_habito = :id")
    suspend fun deleteById(id: Int)

    @Query("SELECT * FROM habitos WHERE id_habito = :id LIMIT 1")
    suspend fun getById(id: Int): HabitoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTracking(item: SeguimientoHabitoEntity)

    @Query("SELECT * FROM seguimiento_habito WHERE id_habito = :habitId AND fecha = :fecha LIMIT 1")
    suspend fun getTrackingByDate(habitId: Int, fecha: String): SeguimientoHabitoEntity?

    @Query("SELECT COUNT(*) FROM seguimiento_habito WHERE id_habito = :habitId AND completado = 1")
    suspend fun completedCount(habitId: Int): Int

    @Query(
        "SELECT h.id_habito as id, h.nombre_habito as nombre, COALESCE(s.completado, 0) as completadoHoy, (SELECT COUNT(*) FROM seguimiento_habito sh WHERE sh.id_habito = h.id_habito AND sh.completado = 1) as racha FROM habitos h LEFT JOIN seguimiento_habito s ON s.id_habito = h.id_habito AND s.fecha = :fecha WHERE h.id_usuario = :userId ORDER BY h.id_habito DESC"
    )
    suspend fun getUiByUser(userId: Int, fecha: String): List<HabitUi>

    @Query("SELECT COUNT(*) FROM habitos WHERE id_usuario = :userId")
    suspend fun countByUser(userId: Int): Int

    @Query(
        "SELECT COUNT(*) FROM habitos h INNER JOIN seguimiento_habito s ON s.id_habito = h.id_habito WHERE h.id_usuario = :userId AND s.fecha = :fecha AND s.completado = 1"
    )
    suspend fun completedTodayByUser(userId: Int, fecha: String): Int
}
