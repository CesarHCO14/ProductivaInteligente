package com.example.productivainteligenteroom.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.data.db.models.ReminderUi
import com.example.productivainteligenteroom.ui.components.EmptyState
import com.example.productivainteligenteroom.vm.MainViewModel

@Composable
fun RecordatoriosScreen(vm: MainViewModel) {
    var titulo by remember { mutableStateOf("") }
    var nota by remember { mutableStateOf("") }
    var lugar by remember { mutableStateOf("") }
    var radius by remember { mutableStateOf("150") }
    var usarGeo by remember { mutableStateOf(false) }
    var prioridad by remember { mutableStateOf("MEDIA") }
    var recurrencia by remember { mutableStateOf("NINGUNA") }
    var editItem by remember { mutableStateOf<ReminderUi?>(null) }
    var deleteId by remember { mutableStateOf<Int?>(null) }
    var showForm by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(Unit) { vm.refreshAll() }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Recordatorios", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)

        OutlinedTextField(
            value = vm.searchQuery.value,
            onValueChange = { vm.searchQuery.value = it },
            label = { Text("Buscar recordatorio") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Button(onClick = { showForm = !showForm }, modifier = Modifier.fillMaxWidth()) {
            Icon(if (showForm) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(if (showForm) "Ocultar formulario" else if (editItem != null) "Editar recordatorio" else "Nuevo recordatorio")
        }

        if (showForm) {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = titulo, onValueChange = { titulo = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = nota, onValueChange = { nota = it }, label = { Text("Nota") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Usar geolocalización")
                        Switch(checked = usarGeo, onCheckedChange = { usarGeo = it })
                    }

                    if (usarGeo) {
                        OutlinedTextField(value = lugar, onValueChange = { lugar = it }, label = { Text("Lugar") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = radius, onValueChange = { radius = it }, label = { Text("Radio en metros") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = { vm.captureLocation(context) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Capturar ubicación actual")
                        }
                    }

                    OutlinedTextField(value = prioridad, onValueChange = { prioridad = it }, label = { Text("Prioridad") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = recurrencia, onValueChange = { recurrencia = it }, label = { Text("Recurrencia") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                    Button(onClick = {
                        if (editItem == null) {
                            vm.addReminder(titulo.ifBlank { "Recordatorio" }, nota, usarGeo, lugar, radius.toIntOrNull() ?: 150, prioridad, recurrencia)
                        } else {
                            vm.updateReminder(
                                id = editItem!!.id,
                                titulo = titulo.ifBlank { "Recordatorio" },
                                nota = nota,
                                lugar = lugar,
                                radius = radius.toIntOrNull() ?: 150,
                                prioridad = prioridad,
                                recurrencia = recurrencia,
                                tipo = if (usarGeo) "GEO" else "HORA",
                                estado = editItem!!.estado,
                                latitud = editItem!!.latitud,
                                longitud = editItem!!.longitud
                            )
                        }
                        titulo = ""; nota = ""; lugar = ""; radius = "150"; usarGeo = false; prioridad = "MEDIA"; recurrencia = "NINGUNA"; editItem = null; showForm = false
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (editItem == null) "Guardar recordatorio" else "Actualizar recordatorio")
                    }
                }
            }
        }

        Text("Lista de recordatorios", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        val items = vm.filteredReminders()
        if (items.isEmpty()) {
            EmptyState("No hay recordatorios")
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items) { r ->
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(r.titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            if (r.nota.isNotBlank()) Text(r.nota, style = MaterialTheme.typography.bodyMedium)
                            Text("Tipo: ${r.tipo} • Prioridad: ${r.prioridad}", style = MaterialTheme.typography.bodySmall)
                            Text("Estado: ${r.estado} • Recurrencia: ${r.recurrencia}", style = MaterialTheme.typography.bodySmall)
                            if (r.lugar.isNotBlank()) Text("Lugar: ${r.lugar} • Radio: ${r.radius}m", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = {
                                    editItem = r
                                    titulo = r.titulo
                                    nota = r.nota
                                    lugar = r.lugar
                                    radius = r.radius.toString()
                                    usarGeo = r.tipo == "GEO"
                                    prioridad = r.prioridad
                                    recurrencia = r.recurrencia
                                    showForm = true
                                }) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(4.dp)); Text("Editar") }
                                TextButton(onClick = { vm.toggleReminderStatus(r.id) }) {
                                    Text(if (r.estado == "PENDIENTE") "Marcar realizado" else "Reabrir")
                                }
                                TextButton(onClick = { deleteId = r.id }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Eliminar") }
                            }
                        }
                    }
                }
            }
        }
    }

    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            confirmButton = { TextButton(onClick = { vm.deleteReminder(id); deleteId = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancelar") } },
            title = { Text("Confirmar eliminación") },
            text = { Text("¿Eliminar recordatorio?") }
        )
    }
}
