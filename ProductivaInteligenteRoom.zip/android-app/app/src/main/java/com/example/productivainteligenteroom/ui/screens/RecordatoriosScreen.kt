package com.example.productivainteligenteroom.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.data.db.models.ReminderUi
import com.example.productivainteligenteroom.ui.components.EmptyState
import com.example.productivainteligenteroom.vm.MainViewModel
import java.time.LocalDate

@Composable
fun RecordatoriosScreen(vm: MainViewModel) {
    var titulo by remember { mutableStateOf("") }
    var nota by remember { mutableStateOf("") }
    var lugar by remember { mutableStateOf("") }
    var radius by remember { mutableStateOf("150") }
    var usarGeo by remember { mutableStateOf(false) }
    var prioridad by remember { mutableStateOf("MEDIA") }
    var recurrencia by remember { mutableStateOf("NINGUNA") }
    var fechaAviso by remember { mutableStateOf(LocalDate.now().toString()) }
    var horaAviso by remember { mutableStateOf("18:00") }
    var editItem by remember { mutableStateOf<ReminderUi?>(null) }
    var deleteId by remember { mutableStateOf<Int?>(null) }
    var showForm by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(Unit) { vm.refreshAll() }

    val items = vm.filteredReminders()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Recordatorios", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)

        OutlinedTextField(
            value = vm.searchQuery.value,
            onValueChange = { vm.searchQuery.value = it },
            label = { Text("Buscar recordatorio") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Button(onClick = { showForm = !showForm }, modifier = Modifier.fillMaxWidth()) {
                    Icon(if (showForm) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (showForm) "Ocultar formulario" else if (editItem != null) "Editar recordatorio" else "Nuevo recordatorio")
                }
            }

            if (showForm) {
                item {
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(value = titulo, onValueChange = { titulo = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = nota, onValueChange = { nota = it }, label = { Text("Nota") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Usar geolocalización")
                                Switch(checked = usarGeo, onCheckedChange = { usarGeo = it })
                            }

                            if (usarGeo) {
                                OutlinedTextField(value = lugar, onValueChange = { lugar = it }, label = { Text("Lugar") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                OutlinedTextField(value = radius, onValueChange = { radius = it }, label = { Text("Radio en metros") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                Button(onClick = { vm.captureLocation(context) }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Capturar ubicación actual")
                                }
                            }

                            OutlinedTextField(value = prioridad, onValueChange = { prioridad = it }, label = { Text("Prioridad: ALTA / MEDIA / BAJA") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = recurrencia, onValueChange = { recurrencia = it }, label = { Text("Recurrencia: NINGUNA / DIARIA / SEMANAL / MENSUAL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                            Text("Alarma / Notificación", fontWeight = FontWeight.SemiBold)

                            OutlinedTextField(
                                value = fechaAviso,
                                onValueChange = { fechaAviso = it.trim() },
                                label = { Text("Fecha aviso: yyyy-MM-dd") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = horaAviso,
                                onValueChange = { horaAviso = it.trim() },
                                label = { Text("Hora aviso: HH:mm") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Text(
                                "Al guardar se programa una notificación local en el celular.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Button(
                                onClick = {
                                    if (editItem == null) {
                                        vm.addReminder(
                                            context = context,
                                            titulo = titulo.ifBlank { "Recordatorio" },
                                            nota = nota,
                                            usarGeo = usarGeo,
                                            lugar = lugar,
                                            radius = radius.toIntOrNull() ?: 150,
                                            prioridad = prioridad.ifBlank { "MEDIA" },
                                            recurrencia = recurrencia.ifBlank { "NINGUNA" },
                                            fechaRecordatorio = fechaAviso,
                                            horaRecordatorio = horaAviso
                                        )
                                    } else {
                                        vm.updateReminder(
                                            context = context,
                                            id = editItem!!.id,
                                            titulo = titulo.ifBlank { "Recordatorio" },
                                            nota = nota,
                                            lugar = lugar,
                                            radius = radius.toIntOrNull() ?: 150,
                                            prioridad = prioridad.ifBlank { "MEDIA" },
                                            recurrencia = recurrencia.ifBlank { "NINGUNA" },
                                            tipo = if (usarGeo) "GEO" else "HORA",
                                            estado = editItem!!.estado,
                                            latitud = editItem!!.latitud,
                                            longitud = editItem!!.longitud,
                                            fechaRecordatorio = fechaAviso,
                                            horaRecordatorio = horaAviso
                                        )
                                    }

                                    titulo = ""
                                    nota = ""
                                    lugar = ""
                                    radius = "150"
                                    usarGeo = false
                                    prioridad = "MEDIA"
                                    recurrencia = "NINGUNA"
                                    fechaAviso = LocalDate.now().toString()
                                    horaAviso = "18:00"
                                    editItem = null
                                    showForm = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (editItem == null) "Guardar y programar aviso" else "Actualizar y reprogramar aviso")
                            }
                        }
                    }
                }
            }

            item {
                Text("Lista de recordatorios", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }

            if (items.isEmpty()) {
                item { EmptyState("No hay recordatorios") }
            } else {
                items(items) { r ->
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(r.titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            if (r.nota.isNotBlank()) Text(r.nota, style = MaterialTheme.typography.bodyMedium)
                            Text("Tipo: ${r.tipo} • Prioridad: ${r.prioridad}", style = MaterialTheme.typography.bodySmall)
                            Text("Estado: ${r.estado} • Recurrencia: ${r.recurrencia}", style = MaterialTheme.typography.bodySmall)
                            if (r.lugar.isNotBlank()) Text("Lugar: ${r.lugar} • Radio: ${r.radius}m", style = MaterialTheme.typography.bodySmall)
                            Text(
                                "Aviso programado: ${r.fechaRecordatorio ?: "Sin fecha"} ${r.horaRecordatorio ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = {
                                    editItem = r
                                    titulo = r.titulo
                                    nota = r.nota
                                    lugar = r.lugar
                                    radius = r.radius.toString()
                                    usarGeo = r.tipo == "GEO"
                                    prioridad = r.prioridad
                                    recurrencia = r.recurrencia
                                    fechaAviso = r.fechaRecordatorio ?: LocalDate.now().toString()
                                    horaAviso = r.horaRecordatorio ?: "18:00"
                                    showForm = true
                                }) {
                                    Icon(Icons.Default.Edit, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("Editar")
                                }

                                TextButton(onClick = { vm.toggleReminderStatus(r.id) }) {
                                    Text(if (r.estado == "PENDIENTE") "Marcar realizado" else "Reabrir")
                                }

                                TextButton(onClick = { deleteId = r.id }) {
                                    Icon(Icons.Default.Delete, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("Eliminar")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null },
            confirmButton = { TextButton(onClick = { vm.deleteReminder(id); deleteId = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancelar") } },
            title = { Text("Confirmar eliminación") },
            text = { Text("¿Eliminar recordatorio?") }
        )
    }
}
