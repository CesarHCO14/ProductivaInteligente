package com.example.productivainteligenteroom.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.ui.charts.ExpensesBarChart
import com.example.productivainteligenteroom.ui.components.KpiCard
import com.example.productivainteligenteroom.ui.components.PremiumHeader
import com.example.productivainteligenteroom.ui.components.SectionCard
import com.example.productivainteligenteroom.vm.MainViewModel

@Composable
fun DashboardScreen(vm: MainViewModel) {
    val d = vm.dashboard.value
    LaunchedEffect(Unit) { vm.refreshAll() }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { PremiumHeader("Dashboard ejecutivo", "Resumen general") }
        item { Text("Indicadores principales", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        item { KpiCard("Total de gastos", "S/ %.2f".format(d.totalGastos), "Monto acumulado registrado") }
        item { KpiCard("Promedio diario", "S/ %.2f".format(d.promedioDiario), "Promedio calculado localmente") }
        item { KpiCard("Proyección mensual", "S/ %.2f".format(d.proyeccionMensual), "Estimación automática") }
        item { KpiCard("Productividad", "${vm.productivityPercent()}%", "${d.habitosCumplidos} hábitos completados de ${d.habitosActivos}") }
        item { KpiCard("Recordatorios activos", d.recordatoriosActivos.toString(), "Con geolocalización: ${d.recordatoriosGeo}") }
        item {
            SectionCard("Resumen ejecutivo") {
                Text("Categoría top: ${vm.categoryTotals().firstOrNull()?.categoria ?: "Sin datos"}")
                Text("Cantidad de gastos: ${vm.expenses.value.size}")
                Text("Cantidad de hábitos: ${vm.habits.value.size}")
                Text("Cantidad de recordatorios: ${vm.reminders.value.size}")
            }
        }
        item {
            SectionCard("Gastos por categoría") {
                val chartData = vm.categoryTotals()
                if (chartData.isEmpty()) Text("No hay datos para mostrar")
                else ExpensesBarChart(chartData, Modifier.fillMaxWidth().height(260.dp))
            }
        }
        item {
            Button(onClick = { vm.refreshAll() }, modifier = Modifier.fillMaxWidth()) {
                Text("Actualizar datos")
            }
        }
    }
}
