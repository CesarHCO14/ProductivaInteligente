package com.example.productivainteligenteroom.ui.screens

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.ui.charts.ExpensesBarChart
import com.example.productivainteligenteroom.ui.components.KpiCard
import com.example.productivainteligenteroom.ui.components.PremiumHeader
import com.example.productivainteligenteroom.ui.components.SectionCard
import com.example.productivainteligenteroom.ui.components.SmartAlertsCard
import com.example.productivainteligenteroom.vm.MainViewModel

@Composable
fun DashboardScreen(vm: MainViewModel) {
    val d = vm.dashboard.value

    LaunchedEffect(Unit) {
        vm.refreshAll()
    }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            PremiumHeader(
                title = "Dashboard ejecutivo",
                subtitle = "Resumen analítico"
            )
        }

        item {
            SmartAlertsCard(vm.smartAlerts.value)
        }

        item {
            Text(
                "Indicadores principales",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }

        item {
            KpiCard(
                title = "Total de gastos",
                value = "S/ %.2f".format(d.totalGastos),
                subtitle = "Monto acumulado registrado"
            )
        }

        item {
            KpiCard(
                title = "Gasto mayor del mes",
                value = d.gastoMayorMes?.let { "S/ %.2f".format(it.monto) } ?: "S/ 0.00",
                subtitle = d.gastoMayorMes?.let { "${it.titulo} • ${it.fecha}" } ?: "Sin datos del mes"
            )
        }

        item {
            KpiCard(
                title = "Categoría con mayor gasto",
                value = d.categoriaMayorMes?.categoria ?: "Sin datos",
                subtitle = d.categoriaMayorMes?.let { "Total mensual: S/ %.2f".format(it.total) } ?: "No hay movimientos"
            )
        }

        item {
            KpiCard(
                title = "Hábitos cumplidos",
                value = "${vm.productivityPercent()}%",
                subtitle = "${d.habitosCumplidos} hábitos completados de ${d.habitosActivos}"
            )
        }

        item {
            KpiCard(
                title = "Avisos vencidos",
                value = d.avisosVencidos.toString(),
                subtitle = "Recordatorios pendientes cuya fecha/hora ya pasó"
            )
        }

        item {
            KpiCard(
                title = "Avisos próximos",
                value = d.avisosProximos.toString(),
                subtitle = "Recordatorios pendientes de los siguientes 7 días"
            )
        }

        item {
            SectionCard("Resumen ejecutivo") {
                Text("Promedio diario: S/ %.2f".format(d.promedioDiario))
                Text("Proyección mensual: S/ %.2f".format(d.proyeccionMensual))
                Text("Recordatorios activos: ${d.recordatoriosActivos}")
                Text("Recordatorios con geolocalización: ${d.recordatoriosGeo}")
            }
        }

        item {
            SectionCard("Gastos por categoría") {
                val chartData = vm.categoryTotals()
                if (chartData.isEmpty()) {
                    Text("No hay datos para mostrar")
                } else {
                    ExpensesBarChart(
                        data = chartData,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                    )
                }
            }
        }

        item {
            Button(
                onClick = { vm.refreshAll() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Actualizar datos")
            }
        }
    }
}
