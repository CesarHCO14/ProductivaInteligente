package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "habitos",
    foreignKeys = [
        ForeignKey(
            entity = UsuarioEntity::class,
            parentColumns = ["id_usuario"],
            childColumns = ["id_usuario"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("id_usuario")]
)
data class HabitoEntity(
    @PrimaryKey(autoGenerate = true) val id_habito: Int = 0,
    val id_usuario: Int,
    val nombre_habito: String
)
