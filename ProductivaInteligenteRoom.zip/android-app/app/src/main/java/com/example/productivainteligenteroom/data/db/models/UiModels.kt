package com.example.productivainteligenteroom.data.db.models

import androidx.annotation.Keep
data class UserUi(
    val id: Int = 0,
    val nombre: String = "",
    val correo: String = ""
)

@Keep
data class ExpenseUi(
    val id: Int,
    val titulo: String,
    val monto: Double,
    val categoria: String,
    val fecha: String
)

data class HabitUi(
    val id: Int = 0,
    val nombre: String = "",
    val completadoHoy: Boolean = false,
    val racha: Int = 0
)

data class ReminderUi(
    val id: Int = 0,
    val titulo: String = "",
    val nota: String = "",
    val tipo: String = "HORA",
    val lugar: String = "",
    val radius: Int = 150,
    val prioridad: String = "MEDIA",
    val estado: String = "PENDIENTE",
    val recurrencia: String = "NINGUNA",
    val latitud: Double? = null,
    val longitud: Double? = null
)

data class DashboardUi(
    val totalGastos: Double = 0.0,
    val promedioDiario: Double = 0.0,
    val proyeccionMensual: Double = 0.0,
    val habitosActivos: Int = 0,
    val habitosCumplidos: Int = 0,
    val recordatoriosActivos: Int = 0,
    val recordatoriosGeo: Int = 0
)

@Keep
data class CategoryAmount(
    val categoria: String,
    val total: Double
)