package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "seguimiento_habito",
    foreignKeys = [
        ForeignKey(
            entity = HabitoEntity::class,
            parentColumns = ["id_habito"],
            childColumns = ["id_habito"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("id_habito"), Index(value = ["id_habito", "fecha"], unique = true)]
)
data class SeguimientoHabitoEntity(
    @PrimaryKey(autoGenerate = true) val id_seguimiento: Int = 0,
    val id_habito: Int,
    val fecha: String,
    val completado: Boolean
)
