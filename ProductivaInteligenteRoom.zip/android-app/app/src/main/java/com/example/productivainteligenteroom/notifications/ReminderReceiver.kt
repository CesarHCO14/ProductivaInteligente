package com.example.productivainteligenteroom.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", System.currentTimeMillis().toInt())
        val titulo = intent.getStringExtra("titulo") ?: "Recordatorio"
        val nota = intent.getStringExtra("nota") ?: ""
        NotificationHelper.showNotification(context, id, titulo, nota)
    }
}
