package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "prioridades")
data class PrioridadEntity(
    @PrimaryKey(autoGenerate = true) val id_prioridad: Int = 0,
    val nombre_prioridad: String
)
