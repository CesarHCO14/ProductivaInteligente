package com.example.productivainteligenteroom.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.vm.MainViewModel

@Composable
fun LoginScreen(context: Context, vm: MainViewModel) {
    var nombre by remember { mutableStateOf("") }
    var correo by remember { mutableStateOf("demo@demo.com") }
    var clave by remember { mutableStateOf("123456") }
    var confirmar by remember { mutableStateOf("") }
    val registerMode by vm.isRegisterMode

    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        ElevatedCard(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    if (registerMode) "Crear cuenta" else "Productiva Inteligente",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(if (registerMode) "Registrarse" else "Inciar sesión")

                if (registerMode) {
                    OutlinedTextField(
                        value = nombre,
                        onValueChange = { nombre = it },
                        label = { Text("Nombre") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = correo,
                    onValueChange = { correo = it },
                    label = { Text("Correo") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = clave,
                    onValueChange = { clave = it },
                    label = { Text("Clave") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (registerMode) {
                    OutlinedTextField(
                        value = confirmar,
                        onValueChange = { confirmar = it },
                        label = { Text("Confirmar clave") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                Button(
                    onClick = {
                        if (registerMode) {
                            vm.register(context, nombre, correo, clave, confirmar)
                        } else {
                            vm.login(context, correo, clave)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (registerMode) "Registrarse" else "Ingresar")
                }

                TextButton(
                    onClick = {
                        vm.toggleRegisterMode()
                        confirmar = ""
                        if (!registerMode) nombre = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (registerMode) "Ya tengo cuenta, iniciar sesión"
                        else "¿No tienes cuenta? Regístrate"
                    )
                }

                if (vm.statusMessage.value.isNotBlank()) {
                    Text(vm.statusMessage.value, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
