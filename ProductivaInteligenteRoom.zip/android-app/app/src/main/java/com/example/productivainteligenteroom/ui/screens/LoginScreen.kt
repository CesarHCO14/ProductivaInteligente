package com.example.productivainteligenteroom.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.productivainteligenteroom.vm.MainViewModel

@Composable
fun LoginScreen(context: Context, vm: MainViewModel) {
    var correo by remember { mutableStateOf("demo@demo.com") }
    var clave by remember { mutableStateOf("123456") }

    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        ElevatedCard(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Productiva Inteligente", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Versión local con Room + SQLite")
                OutlinedTextField(value = correo, onValueChange = { correo = it }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = clave, onValueChange = { clave = it }, label = { Text("Clave") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(onClick = { vm.login(context, correo, clave) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ingresar")
                }
                if (vm.statusMessage.value.isNotBlank()) {
                    Text(vm.statusMessage.value, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
