package com.example.productivainteligenteroom.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RewriteQueriesToDropUnusedColumns
import androidx.room.Update
import com.example.productivainteligenteroom.data.db.entities.GastoEntity
import com.example.productivainteligenteroom.data.db.models.CategoryAmount
import com.example.productivainteligenteroom.data.db.models.ExpenseUi

@Dao
@RewriteQueriesToDropUnusedColumns
interface GastoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(gasto: GastoEntity): Long

    @Update
    suspend fun update(gasto: GastoEntity)

    @Query("DELETE FROM gastos WHERE id_gasto = :id")
    suspend fun deleteById(id: Int)

    @Query(" SELECT g.id_gasto as id, g.titulo as titulo, g.monto as monto, c.nombre_categoria as categoria, g.fecha as fecha FROM gastos g INNER JOIN categorias_gasto c ON c.id_categoria = g.id_categoria WHERE g.id_usuario = :userId ORDER BY g.id_gasto DESC")
    suspend fun getUiByUser(userId: Int): List<ExpenseUi>

    @Query("SELECT * FROM gastos WHERE id_gasto = :id LIMIT 1")
    suspend fun getById(id: Int): GastoEntity?

    @Query("SELECT COALESCE(SUM(monto), 0) FROM gastos WHERE id_usuario = :userId")
    suspend fun totalByUser(userId: Int): Double

    @Query("SELECT COUNT(*) FROM gastos WHERE id_usuario = :userId")
    suspend fun countByUser(userId: Int): Int

    @Query(
        "SELECT c.nombre_categoria as categoria, COALESCE(SUM(g.monto),0) as total  FROM gastos g INNER JOIN categorias_gasto c ON c.id_categoria = g.id_categoria WHERE g.id_usuario = :userId GROUP BY c.id_categoria, c.nombre_categoria ORDER BY total DESC"
    )
    suspend fun totalsByCategory(userId: Int): List<CategoryAmount>
}
