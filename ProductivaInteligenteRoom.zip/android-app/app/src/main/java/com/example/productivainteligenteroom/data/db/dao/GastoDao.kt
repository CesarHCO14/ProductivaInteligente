package com.example.productivainteligenteroom.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RewriteQueriesToDropUnusedColumns
import androidx.room.Update
import com.example.productivainteligenteroom.data.db.entities.GastoEntity
import com.example.productivainteligenteroom.data.db.models.CategoryAmount
import com.example.productivainteligenteroom.data.db.models.ExpenseUi

@Dao
@RewriteQueriesToDropUnusedColumns
interface GastoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(gasto: GastoEntity): Long

    @Update
    suspend fun update(gasto: GastoEntity)

    @Query("DELETE FROM gastos WHERE id_gasto = :id")
    suspend fun deleteById(id: Int)

    @Query("""
        SELECT g.id_gasto as id, g.titulo as titulo, g.monto as monto,
               c.nombre_categoria as categoria, g.fecha as fecha
        FROM gastos g
        INNER JOIN categorias_gasto c ON c.id_categoria = g.id_categoria
        WHERE g.id_usuario = :userId
        ORDER BY g.fecha DESC, g.id_gasto DESC
    """)
    suspend fun getUiByUser(userId: Int): List<ExpenseUi>

    @Query("""
        SELECT g.id_gasto as id, g.titulo as titulo, g.monto as monto,
               c.nombre_categoria as categoria, g.fecha as fecha
        FROM gastos g
        INNER JOIN categorias_gasto c ON c.id_categoria = g.id_categoria
        WHERE g.id_usuario = :userId
          AND (:inicio = '' OR DATE(TRIM(g.fecha)) >= DATE(TRIM(:inicio)))
          AND (:fin = '' OR DATE(TRIM(g.fecha)) <= DATE(TRIM(:fin)))
          AND (:categoria = '' OR c.nombre_categoria = :categoria)
          AND (:mes = '' OR SUBSTR(TRIM(g.fecha), 1, 7) = :mes)
          AND (:montoMin IS NULL OR g.monto >= :montoMin)
          AND (:montoMax IS NULL OR g.monto <= :montoMax)
        ORDER BY
          CASE WHEN :orden = 'fecha_desc' THEN g.fecha END DESC,
          CASE WHEN :orden = 'fecha_asc' THEN g.fecha END ASC,
          CASE WHEN :orden = 'monto_desc' THEN g.monto END DESC,
          CASE WHEN :orden = 'monto_asc' THEN g.monto END ASC,
          CASE WHEN :orden = 'categoria_asc' THEN c.nombre_categoria END ASC,
          g.id_gasto DESC
    """)
    suspend fun getUiAdvanced(
        userId: Int,
        inicio: String,
        fin: String,
        categoria: String,
        mes: String,
        montoMin: Double?,
        montoMax: Double?,
        orden: String
    ): List<ExpenseUi>

    @Query("SELECT * FROM gastos WHERE id_gasto = :id LIMIT 1")
    suspend fun getById(id: Int): GastoEntity?

    @Query("SELECT COALESCE(SUM(monto), 0) FROM gastos WHERE id_usuario = :userId")
    suspend fun totalByUser(userId: Int): Double

    @Query("SELECT COUNT(*) FROM gastos WHERE id_usuario = :userId")
    suspend fun countByUser(userId: Int): Int

    @Query("""
        SELECT c.nombre_categoria as categoria, COALESCE(SUM(g.monto),0) as total
        FROM gastos g
        INNER JOIN categorias_gasto c ON c.id_categoria = g.id_categoria
        WHERE g.id_usuario = :userId
        GROUP BY c.id_categoria, c.nombre_categoria
        ORDER BY total DESC
    """)
    suspend fun totalsByCategory(userId: Int): List<CategoryAmount>

    @Query("""
        SELECT c.nombre_categoria as categoria, COALESCE(SUM(g.monto),0) as total
        FROM gastos g
        INNER JOIN categorias_gasto c ON c.id_categoria = g.id_categoria
        WHERE g.id_usuario = :userId
          AND SUBSTR(TRIM(g.fecha), 1, 7) = :mes
        GROUP BY c.id_categoria, c.nombre_categoria
        ORDER BY total DESC
        LIMIT 1
    """)
    suspend fun topCategoryByMonth(userId: Int, mes: String): CategoryAmount?

    @Query("""
        SELECT g.id_gasto as id, g.titulo as titulo, g.monto as monto,
               c.nombre_categoria as categoria, g.fecha as fecha
        FROM gastos g
        INNER JOIN categorias_gasto c ON c.id_categoria = g.id_categoria
        WHERE g.id_usuario = :userId
          AND SUBSTR(TRIM(g.fecha), 1, 7) = :mes
        ORDER BY g.monto DESC
        LIMIT 1
    """)
    suspend fun biggestExpenseByMonth(userId: Int, mes: String): ExpenseUi?

    @Query("""
        SELECT COALESCE(AVG(g.monto), 0)
        FROM gastos g
        WHERE g.id_usuario = :userId
    """)
    suspend fun averageExpense(userId: Int): Double

    @Query("""
        SELECT COALESCE(SUM(g.monto), 0)
        FROM gastos g
        INNER JOIN categorias_gasto c ON c.id_categoria = g.id_categoria
        WHERE g.id_usuario = :userId AND c.nombre_categoria = :categoria
    """)
    suspend fun totalByCategory(userId: Int, categoria: String): Double
}
