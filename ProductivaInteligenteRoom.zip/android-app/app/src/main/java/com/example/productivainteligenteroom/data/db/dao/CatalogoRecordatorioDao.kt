package com.example.productivainteligenteroom.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.productivainteligenteroom.data.db.entities.EstadoRecordatorioEntity
import com.example.productivainteligenteroom.data.db.entities.PrioridadEntity
import com.example.productivainteligenteroom.data.db.entities.RecurrenciaEntity
import com.example.productivainteligenteroom.data.db.entities.TipoRecordatorioEntity

@Dao
interface CatalogoRecordatorioDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTipos(items: List<TipoRecordatorioEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPrioridades(items: List<PrioridadEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertEstados(items: List<EstadoRecordatorioEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertRecurrencias(items: List<RecurrenciaEntity>)

    @Query("SELECT id_tipo FROM tipos_recordatorio WHERE nombre_tipo = :name LIMIT 1")
    suspend fun getTipoId(name: String): Int?

    @Query("SELECT id_prioridad FROM prioridades WHERE nombre_prioridad = :name LIMIT 1")
    suspend fun getPrioridadId(name: String): Int?

    @Query("SELECT id_estado FROM estados_recordatorio WHERE nombre_estado = :name LIMIT 1")
    suspend fun getEstadoId(name: String): Int?

    @Query("SELECT id_recurrencia FROM recurrencias WHERE nombre_recurrencia = :name LIMIT 1")
    suspend fun getRecurrenciaId(name: String): Int?
}
