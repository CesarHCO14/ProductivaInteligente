package com.example.productivainteligenteroom.data.db.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "recordatorios",
    foreignKeys = [
        ForeignKey(entity = UsuarioEntity::class, parentColumns = ["id_usuario"], childColumns = ["id_usuario"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = TipoRecordatorioEntity::class, parentColumns = ["id_tipo"], childColumns = ["id_tipo"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = PrioridadEntity::class, parentColumns = ["id_prioridad"], childColumns = ["id_prioridad"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = EstadoRecordatorioEntity::class, parentColumns = ["id_estado"], childColumns = ["id_estado"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = RecurrenciaEntity::class, parentColumns = ["id_recurrencia"], childColumns = ["id_recurrencia"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [
        Index("id_usuario"),
        Index("id_tipo"),
        Index("id_prioridad"),
        Index("id_estado"),
        Index("id_recurrencia")
    ]
)
data class RecordatorioEntity(
    @PrimaryKey(autoGenerate = true) val id_recordatorio: Int = 0,
    val id_usuario: Int,
    val titulo: String,
    val nota: String,
    val id_tipo: Int,
    val id_prioridad: Int,
    val id_estado: Int,
    val id_recurrencia: Int,
    val lugar: String?,
    val radio: Int?,
    val latitud: Double?,
    val longitud: Double?,
    val fecha_recordatorio: String?,
    val hora_recordatorio: String?
)
